export const GET_ALL_USERS = 'GET_ALL_USERS';
export const DELETE_USER = 'DELETE_USER';